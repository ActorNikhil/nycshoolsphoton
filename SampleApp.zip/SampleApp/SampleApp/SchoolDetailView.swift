//
//  SchoolDetailView.swift
//  SampleApp
//
//  Created by Nikhil on 2/17/24.
//

import Foundation
import SwiftUI

struct SchoolDetailView: View {
    
    var school: School
    
    var body: some View {
        VStack {
            Text(school.overview_paragraph)
        }
        .padding()
    }
}

struct SchoolDetailView_Previews: PreviewProvider {
    static var previews: some View {
        SchoolListView()
    }
}
