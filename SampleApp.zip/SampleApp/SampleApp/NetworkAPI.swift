//
//  NetworkAPI.swift
//  SampleApp
//
//  Created by Nikhil on 2/17/24.
//


import Foundation

enum API: String {
    case schoolList = "https://data.cityofnewyork.us/resource/s3k6-pzi2.json"
}

struct NetworkAPI {
    
    static func getResponse(_ urlString: API = .schoolList, completion: @escaping ([School]) -> ()) {
        
        guard let url = URL(string: urlString.rawValue) else { return }
        
        let request = URLRequest(url: url)
        
        URLSession.shared.dataTask(with: request) { data, _, _ in
            
            do {
                let result =  try JSONDecoder().decode([School].self, from: data!)
                completion(result)
            } catch {
                print(error.localizedDescription)
            }
        }
    }
    
}

