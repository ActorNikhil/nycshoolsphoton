//
//  HighSchoolsViewModel.swift
//  SampleApp
//
//  Created by Nikhil on 2/17/24.
//

import Foundation

class HighSchoolsViewModel: ObservableObject {
    
    @Published var schoolList = [School]()
    
    func requestForNYCSchoolList() {
        NetworkAPI.getResponse { result in
            self.schoolList = result
        }
    }
}
