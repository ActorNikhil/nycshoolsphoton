//
//  School.swift
//  SampleApp
//
//  Created by Nikhil on 2/17/24.
//

import Foundation

struct School: Codable, Identifiable {
    var id = UUID()
    let dbn: String
    let school_name: String
    let overview_paragraph: String
}
