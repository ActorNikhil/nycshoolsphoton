//
//  SampleAppApp.swift
//  SampleApp
//
//  Created by Nikhil on 2/17/24.
//

import SwiftUI

@main
struct SampleAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
