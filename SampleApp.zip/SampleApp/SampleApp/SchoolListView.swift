//
//  SchoolListView.swift
//  SampleApp
//
//  Created by Nikhil on 2/17/24.
//

import SwiftUI

struct SchoolListView: View {
    
    @ObservedObject var highSchoolsViewModel = HighSchoolsViewModel()
    
    @State var isShown = false
    
    var body: some View {
        VStack {
            ForEach(highSchoolsViewModel.schoolList) { school in
                ZStack {
                    Text(school.dbn)
                    Text(school.school_name)
                }
                .padding()
                                
                NavigationLink(destination: SchoolDetailView(school: school), isActive: $isShown, label: {})
                
                .onTapGesture {
                    isShown = true
                }
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        SchoolListView()
    }
}
